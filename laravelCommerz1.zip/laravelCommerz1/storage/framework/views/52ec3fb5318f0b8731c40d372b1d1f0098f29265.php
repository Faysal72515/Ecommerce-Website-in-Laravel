<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('/css/external_css.css' )); ?>">
    <link type="image/x-icon" rel="icon" href="<?php echo e(url('/images/website.png' )); ?>">
    <title>Home</title>


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



</head>

<body>
    <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('/images/website.png' )); ?>" alt="logo" style="width:40px;"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
            </li>
            <li class="nav-item "><a class="nav-link" href="<?php echo e(url('/signup' )); ?>"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
            <li class="nav-item "><a class="nav-link" href="<?php echo e(route('login1' )); ?>"><span class="glyphicon glyphicon-user"></span> Login</a></li>
            <li class="nav-item "><a class="nav-link" href="<?php echo e(url('/cart' )); ?>"><span class="fa fa-shopping-cart" style="font-size:24px; color:aquamarine"></span></a></li>
        </ul>
        </div>
      </nav>
      <br>

    <!-- Cart items details -->
    <div class="small-container cart-page">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <table>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <div class="cart-info">
                        <img src="<?php echo e(asset($cart->options['image'])); ?>">
                        <div>
                            <p>Product Name: <?php echo e($cart->name); ?></p>
                            <small>Price: <?php echo e($cart->price); ?> TK</small>
                            <br>
                            <a href="<?php echo e(url('/remove-item/'. $cart->rowId)); ?>">Remove</a>
                        </div>
                    </div>
                </td>
                <td><?php echo e($cart->qty); ?></td>
                <td><?php echo e($cart->options['total']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div class="total-price">
            <table>
                <tr>
                    <td>Subtotal</td>
                    <td><?php echo e($subTotal); ?></td>
                </tr>
                <tr>
                    <td><button class="btn btn-success" onclick="window.location='<?php echo e(url('example1')); ?>'">Checkout</button></td>
                </tr>
            </table>
        </div>
    </div>

    <!-- javascript -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script>
        var MenuItems = document.getElementById("MenuItems");
        MenuItems.style.maxHeight = "0px";
        function menutoggle() {
            if (MenuItems.style.maxHeight == "0px") {
                MenuItems.style.maxHeight = "200px"
            }
            else {
                MenuItems.style.maxHeight = "0px"
            }
        }
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravelCommerz1\resources\views/cart.blade.php ENDPATH**/ ?>