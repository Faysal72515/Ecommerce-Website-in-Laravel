<!DOCTYPE html>
<html lang="en && bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('/css/external_css.css' )); ?>">
    <link type="image/x-icon" rel="icon" href="<?php echo e(url('/images/website.png' )); ?>">
    <title>Login</title>


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

      <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('/images/website.png' )); ?>" alt="logo" style="width:40px;"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
            </li>

            <li class="nav-item "><a class="nav-link" href="<?php echo e(url('/signup')); ?>"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
            <li class="nav-item "><a class="nav-link" href="<?php echo e(url('/login1' )); ?>"><span class="glyphicon glyphicon-user"></span> Login</a></li>
        </ul>
        </div>
      </nav>
      <br>


      <div class="container">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div class="form-container">
                    <div class="form-btn">
                        <span><b style="color: red;">Sign In</b></span>
                        <hr style="border: none; background: #ff523b; height: 3px;">
                    </div>

                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                        <form action="/users" method="GET">
                            <?php echo csrf_field(); ?>
                            <table>
                                <tr>
                                    <td>Email: </td> <td> <input type="email" name="email" placeholder="Email address" required> </td>
                                </tr>
                                <tr>
                                    <td>Password: </td> <td> <input type="password" name="pass" placeholder="Enter Password"> </td>
                                </tr>
                                <tr>
                                    <td></td><td><button type="submit" class="btn btn-outline-success btn-sm btn-block">Login</button></td>
                                </tr>
                                <tr> <td> </td> <td><a href="<?php echo e(route('password.request')); ?>">Forget Password</a> </td> <td> </td></tr>

                            </table>
                        </form>
                </div>
            </div>
            <div class="col-sm-4"></div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravelCommerz1\resources\views/login.blade.php ENDPATH**/ ?>