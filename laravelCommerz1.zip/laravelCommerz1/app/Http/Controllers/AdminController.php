<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use SebastianBergmann\Type\VoidType;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->only('admin_dash');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $admin_name= $request->has('admin')?$request->get('admin'):'';
        $admin_pass= $request->has('pass')?$request->get('pass'):'';

        $adminInfo = Admin::where('adminName', '=', $admin_name)->where('adminPassword','=',$admin_pass)->first();

        if(isset($adminInfo) && $adminInfo != null){
            $admin_controller =new AdminController;
            return $admin_controller-> admin_dash();
        }else{
            return redirect()->back();
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function show(Admin $admin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function edit(Admin $admin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Admin $admin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Admin  $admin
     * @return \Illuminate\Http\Response
     */
    public function destroy(Admin $admin)
    {
        //
    }
    public function admin_dash(){
        $products = Product::all();
        $returnProducts = array();
        foreach($products as $product){
            $images = explode('|', $product->image);

            $returnProducts[]=[
                'name'=> $product->name,
                'price'=> $product->price,
                'quantity'=> $product->quantity,
                'details'=>$product->details,
                'image'=>$images[0],

            ];
        }

        return view('dashboard', compact('returnProducts'));
    }
    public function logoutadmin()
    {
        $this->middleware('guest')->except('logoutadmin');
        return redirect()->route('loginadmin');
    }

    public function alluser(){
        $users = User::all();
        return view('showAlluser', compact('users'));
    }


    public function sel(){
        $products = DB::select('select * from products');
        return view('dashboard', ['products'=>$products]);
    }

    public function des($id) {
        DB::delete('delete from products where id = ?',[$id]);
        echo "Record deleted successfully.<br/>";
        echo '<a href = "/admin_dashboard">Click Here</a> to go back.';
     }

}