<?php

namespace App\Http\Controllers;

use App\Models\Newproduct;
use Gloudemans\Shoppingcart\Facades\Cart;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
//
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        //-------------------------------------------Copy data one table data to another table----------------------------
        Product::query()
        ->where('updated_at', '<', now()->subminutes(1))
        ->each(function ($oldPost) {
            $newPost = $oldPost->replicate();
            $newPost->setTable('newproducts');
            $newPost->save();
            //$newPost->delete();
        });

//DB::table('newclients')->where('name', 'Faysal')->delete();

//-------------------------------------------delete the duplicate data from table-----------------------

        // Get all duplicated values. Replace 'table' and 'name' accordingly
        $duplicates = DB::table('newproducts') // replace table by the table name where you want to search for duplicated values
                ->select('id', 'name') // name is the column name with duplicated values
                ->whereIn('name', function ($q){
                $q->select('name')
                ->from('newproducts')
                ->groupBy('name')
                ->havingRaw('COUNT(*) > 1');
                })
                ->orderBy('name')
                ->orderBy('id') // keep smaller id (older), to keep biggest id (younger) replace with this ->orderBy('id', 'desc')
                ->get();

        $value = "";

        // loop throuht results and keep first duplicated value
        foreach ($duplicates as $duplicate) {
            if($duplicate->name === $value)
            {
                DB::table('newproducts')->where('id', $duplicate->id)->delete(); // comment out this line the first time to check what will be deleted and keeped
                echo "$duplicate->name with id $duplicate->id deleted! \n";
            }
            else
                echo "$duplicate->name with id $duplicate->id keeped \n";
                $value = $duplicate->name;
            }



//--------------------------------------------------------------------------------------



        $product =new Product();
        $product->name= $request->has('name') ? $request->get('name') : '';
        $product->price= $request->has('price') ? $request->get('price') : '';
        $product->quantity= $request->has('quantity') ? $request->get('quantity') : '';
        $product->details= $request->has('details') ? $request->get('details') : '';
        $product->is_active= 1;

        if ($request->hasFile('images')) {
            $files = $request->file('images');

            $imageLocation= array();
            $i=0;
            foreach ($files as $file) {
                $extension = $file->getClientOriginalExtension();
                $fileName= 'product_'. time() . ++$i . '.' . $extension;
                $location= '/images/uploads/';
                $file->move(public_path() . $location, $fileName);
                $imageLocation[]= $location. $fileName;
            }

            $product->image= implode('|', $imageLocation);
            $product->save();
            return back()->with('success', 'Product Successfully Saved!');
        } else {
            return back()->with('error', 'Product was not saved Successfully!');
        }


}

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        $images = explode('|', $product->image);
        return view('product_details', compact('product', 'images'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }

    public function home(){
        //$homeProduct = Product::all();
        $homeProduct = Product::all();
        return view('welcome', compact('homeProduct'));
    }

    public function addToCart(Request $request){
        $id = $request->has('pid')? $request->get('pid'):'';
        $name = $request->has('name')? $request->get('name'):'';
        $size = $request->has('size')? $request->get('size'):'';
        $quantity = $request->has('quantity')? $request->get('quantity'):'';
        $price = $request->has('price')? $request->get('price'):'';

        $images = Product::find($id)->image;
        $image = explode('|', $images)[0];
        $cart = Cart::content()->where('id', $id)->first();

        if (isset($cart) && $cart != null){
            $quantity= ((int)$quantity + (int)$cart->qty);
            $total= ((int)$quantity * (int)$price);
            Cart::update($cart->rowId, ['qty'=>$quantity, 'options'=> ['size' => $size, 'image'=>$image, 'total'=> $total]]);
        } else{
            $total= ((int)$quantity * (int)$price);
            Cart::add($id, $name, $quantity, $price, ['size' => $size, 'image'=>$image, 'total'=> $total]);
        }

        return redirect('/')->with('success', 'Product Added to Your Cart!');

    }

    public function viewCart(){
        $carts= Cart::content();
        $subTotal= Cart::subtotal();
        return view('cart', compact('carts', 'subTotal'));
    }

    public function removeItem($rowId){
        Cart::remove($rowId);
        return redirect('/cart')->with('success', 'Product Removed Successfully!');
    }


    public function direct(Product $product)
    {
        $images = explode('|', $product->image);
        return view('welcome', compact('product', 'images'));
    }

    // public function show_after(Product $product)
    // {
    //     $images = explode('|', $product->image);
    //     return view('product_details_after', compact('product', 'images'));
    // }




}