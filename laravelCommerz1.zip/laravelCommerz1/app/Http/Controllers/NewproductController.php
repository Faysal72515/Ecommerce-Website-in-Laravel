<?php

namespace App\Http\Controllers;

use App\Models\Newproduct;
use Illuminate\Http\Request;
use Gloudemans\Shoppingcart\Facades\Cart;
class NewproductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Newproduct  $newproduct
     * @return \Illuminate\Http\Response
     */
    public function show(Newproduct $newproduct)
    {
        $images = explode('|', $newproduct->image);
        return view('product_details_after', compact('newproduct', 'images'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Newproduct  $newproduct
     * @return \Illuminate\Http\Response
     */
    public function edit(Newproduct $newproduct)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Newproduct  $newproduct
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Newproduct $newproduct)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Newproduct  $newproduct
     * @return \Illuminate\Http\Response
     */
    public function destroy(Newproduct $newproduct)
    {
        //
    }


    public function addToCart(Request $request){
        $id = $request->has('pid')? $request->get('pid'):'';
        $name = $request->has('name')? $request->get('name'):'';
        $size = $request->has('size')? $request->get('size'):'';
        $quantity = $request->has('quantity')? $request->get('quantity'):'';
        $price = $request->has('price')? $request->get('price'):'';

        $images = Newproduct::find($id)->image;
        $image = explode('|', $images)[0];
        $cart = Cart::content()->where('id', $id)->first();

        if (isset($cart) && $cart != null){
            $quantity= ((int)$quantity + (int)$cart->qty);
            $total= ((int)$quantity * (int)$price);
            Cart::update($cart->rowId, ['qty'=>$quantity, 'options'=> ['size' => $size, 'image'=>$image, 'total'=> $total]]);
        } else{
            $total= ((int)$quantity * (int)$price);
            Cart::add($id, $name, $quantity, $price, ['size' => $size, 'image'=>$image, 'total'=> $total]);
        }

        return redirect('/new_cart')->with('success', 'Product Added to Your Cart!');

    }



    public function removeItem($rowId){
        Cart::remove($rowId);
        return redirect('/new_cart')->with('success', 'Product Removed Successfully!');
    }

    public function viewCartnew(){
        $carts= Cart::content();
        $subTotal= Cart::subtotal();
        return view('new_cart', compact('carts', 'subTotal'));
    }
}