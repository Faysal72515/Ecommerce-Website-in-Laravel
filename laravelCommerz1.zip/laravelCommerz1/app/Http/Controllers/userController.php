<?php

namespace App\Http\Controllers;

use App\Models\Newproduct;
use App\Models\Product;
use App\Models\Productnew;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;

class userController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        $uemail= $request->has('email')?$request->get('email'):'';
        $pass= $request->has('pass')?$request->get('pass'):'';

        $userInfo = User::where('email', '=', $uemail)->where('password','=',$pass)->first();

        if(isset($userInfo) && $userInfo != null){
            $user_controller =new userController;
            return $user_controller-> adduser();
        }else{
            return redirect()->back();
        }

/////////////////////////////////////////////////////////////////


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $request->validate([
            'name'=> ['required', 'string', 'max:255'],
            'email'=> ['required', 'string', 'email', 'unique:users'],
            'pass'=> ['required', 'string', 'min:6'],
            'mobile'=> ['required', 'numeric'],
            'area'=> ['required', 'string', 'max:255'],
         ]);

     user::insert([
        'name'=> $request->has('name') ? $request->get('name') : '',

        'email'=> $request->has('email') ? $request->get('email') : '',
        'mobile'=> $request->has('mobile') ? $request->get('mobile') : '',
        'area'=> $request->has('area') ? $request->get('area') : '',
        'gender'=> $request->has('gender') ? $request->get('gender') : '',
        'password'=> $request->has('pass') ? $request->get('pass') : '',

    ]);

    return redirect()->route('login1');

    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


   public function adduser(){

        $from_user_products = Newproduct::all();
        //dd($fetchproducts);
        return view('products', compact('from_user_products'));
    }



    public function logout()
    {
        $this->middleware('guest')->except('logout');
        return redirect()->route('login1');
    }


}