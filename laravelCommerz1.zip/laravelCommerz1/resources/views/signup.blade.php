<!DOCTYPE html>
<html lang="en && bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link type="image/x-icon" rel="icon" href="{{  url('/images/website.png' ) }}">
    <title>Registration</title>


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<style>

</style>
<body>

      <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <a class="navbar-brand" href="{{ url('/') }}"><img src="{{ url('/images/website.png' ) }}" alt="logo" style="width:40px;"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="{{ url('/') }}">Home</a>
            </li>

            <li class="nav-item "><a class="nav-link" href="{{ url('/signup') }}"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
            <li class="nav-item "><a class="nav-link" href="{{ url('/login1' )  }}"><span class="glyphicon glyphicon-user"></span> Login</a></li>
        </ul>
        </div>
      </nav>
      <br>



      <div class="container">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div class="form-container">
                    <div class="form-btn">
                        <span><b style="color: red;">Sign Up</b></span>
                        <hr style="border: none; background: #ff523b; height: 3px;">
                    </div>
                        <form method="POST" action="/users" enctype="multipart/form-data">
                            @csrf
                            <table>
                                <tr>
                                    <td>Name: </td> <td> <input type="text" name="name" placeholder="Enter Name.."> </td>
                                </tr>
                                <tr>
                                    <td>Email: </td> <td> <input type="email" name="email" placeholder="Email address"> </td>
                                </tr>
                                <tr>
                                    <td>Mobile: </td> <td> <input type="text" name="mobile" placeholder="Mobile No."> </td>
                                </tr>
                                <tr>
                                    <td>Area: </td> <td> <input type="text" name="area" placeholder="Area."> </td>
                                </tr>
                                <tr>
                                    <td>Gender: </td>
                                    <td>
                                        <input type="radio"  name="gender" value="male">
                                          <label for="male">Male</label>
                                          <input type="radio"  name="gender" value="female">
                                          <label for="female">Female</label>
                                          <input type="radio" name="gender" value="common">
                                          <label for="common">Common</label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Password: </td> <td> <input type="password" name="pass" placeholder="Enter Password"> </td>
                                </tr>


                                <tr> <td> </td> <td> </td> <td> </td></tr>
                                <tr> <td> </td> <td> </td> <td> </td></tr>
                                <tr>
                                     <td></td><td><button type="submit" class="btn btn-outline-secondary btn-sm btn-block">Submit</button></td> <td> </td>
                                </tr>
                            </table>
                        </form>
                </div>
            </div>
            <div class="col-sm-4"></div>
        </div>
    </div>
</body>
</html>
