<!DOCTYPE html>
<html lang="en && bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link type="text/css" rel="stylesheet" href="{{ url('/css/external_css.css' )}}">
    <link type="image/x-icon" rel="icon" href="{{  url('/images/website.png' ) }}">
    <title>Home | Products</title>


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

      <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <a class="navbar-brand" href="{{ url('/users')  }}"><img src="{{ url('/images/website.png' ) }}" alt="logo" style="width:40px;"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="{{ url('/users')  }}">Products</a>
            </li>

            <li class="nav-item "><a class="nav-link" href="{{ url('/users' )  }}"><span class="glyphicon glyphicon-user"></span> Profile</a></li>
            <li class="nav-item " style="padding-left: 950px;;"><a class="nav-link" href="{{ url('/new_cart' ) }}"><span class="fa fa-shopping-cart" style="font-size:24px; color:chartreuse"></span></a></li>
            <li class="nav-item "><a class="nav-link" href="{{ route('logout')  }}"><span class="glyphicon glyphicon-user"></span> Logout</a></li>
        </ul>
        </div>
      </nav>
      <br>

      <div class="container">
        <div class="row">
                @foreach($from_user_products as $product)
                    <p class="zoom">
                        <a href="{{ url('/newproducts/'. $product->id) }}" target="_self"><img src="{{asset(explode('|', $product->image)[0])}}" width="75" height="95"></a><br>
                        Name: <strong>{{ $product->name }}</strong> <br>
                        Price: {{ $product->price }} TK <br>
                        <a href="" style="color: red;">Add to Cart</a>
                    </p>
               @endforeach
        </div>
    </div>
</body>
</html>
