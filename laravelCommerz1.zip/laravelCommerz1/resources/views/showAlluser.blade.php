<!DOCTYPE html>
<html lang="en && bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link type="text/css" rel="stylesheet" href="{{ url('/css/external_css.css' )}}">
    <link type="image/x-icon" rel="icon" href="{{  url('/images/website.png' ) }}">
    <title>Admin | Users</title>


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>


    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"></head>




</head>
<style>
table{
    border: 1px solid black;
     width: 100%;
     text-align:center;
}

    </style>
<body>

      <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <a class="navbar-brand" href="{{ url('/dashboard')  }}"><img src="{{ url('/images/website.png' ) }}" alt="logo" style="width:30px;"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavbar">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="">Products</a>
            </li>
            <li class="nav-item "><a class="nav-link" href="{{ route('allusers')  }}"><span class="fa fa-user"></span> User</a></li>
            <li class="nav-item "><a class="nav-link" href="{{ url('#' )  }}"><span class="fas fa-orders"></span>Order</a></li>
            <li class="nav-item "><a class="nav-link" href="{{ route('logoutadmin' ) }}"><span class="fas fa-logout"></span> Logout</a></li>
        </ul>
        </div>
      </nav>

      <div class="container-fluid">
        @if(session()->has('success'))
            <div class="alert alert-success">
                {{ session()->get('success') }}
            </div>
         @endif
        <div class="row">
            <div class="col-sm-8" style="background-color:lavender;">
              <h5 style="text-align: center;">All User</h5>
              <hr style="border: none; background: green; height: 3px;">
              <table>
                <tr>
                  <td>ID</td>
                  <td>Name</td>
                  <td>Email</td>
                  <td>Mobile No.</td>
                  <td>Area</td>
                  <td>Actions</td>
                </tr>
            </table>
            @foreach ($users as $user)

            <table>
                <tr>
                  <td width="5%">$</td>
                  <td width="21%">{{ $user->name}}</td>
                  <td width="9%">{{ $user->email}}</td>
                  <td width="25%">{{ $user->mobile}}</td>
                  <td>{{ $user->area}}</td>
                  <td>
                      <button type="submit" class="btn-outline-success btn-sm btn-block">Update</button>
                      <button type="submit" class="btn-outline-danger btn-sm btn-block">HDelete</button>
                      <button type="submit" class="btn-outline-warning btn-sm btn-block">SDelete</button>
                  </td>
                </tr>
            </table>

      @endforeach

            </div>
            <div class="col-sm-4"  style="background-color:lavenderblush;">
            <h6 style="text-align: center; color:blueviolet">Find User</h6>
            <hr style="border: none; background: blue; height: 3px;">
                <form action="">
                    @csrf
                    <table style="background-color: wheat; border: none;">
                        <tr>
                            <td> </td> <td> <input type="text" name="search" placeholder="Search through Email "> </td> <td><button type="submit" class="btn-outline-primary btn-sm ">Search</button></td>
                        </tr>
                    </table>
                </form>
        </div>

    </div>

<!-- javascript -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
