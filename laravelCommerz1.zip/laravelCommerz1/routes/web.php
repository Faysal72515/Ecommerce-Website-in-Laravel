<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/', '\App\Http\Controllers\ProductController@home')->name('home');

Route::get('/signup', function () {
    return view('signup');
})->name('signup');

Route::get('/login1', function () {
    return view('login');
})->name('login1');

Route::resource('/users',\App\Http\Controllers\userController::class);

Route::get('/after_login', '\App\Http\Controllers\userController@adduser')->name('after_login')->middleware('auth');
// Route::get('/add_product', function () {
//     return view('products');
// })->name('add_products');
Route::get('logout', '\App\Http\Controllers\userController@logout')->name('logout')->middleware('auth');
Auth::routes();


Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::resource('/adminlogin', \App\Http\Controllers\AdminController::class);
Route::get('/loginadmin', function () {return view('adminlogin');})->name('loginadmin');
Route::get('/admin_dashboard', '\App\Http\Controllers\AdminController@admin_dash')->name('admin_dashboard');
Route::get('/logoutadmin', '\App\Http\Controllers\AdminController@logoutadmin')->name('logoutadmin');
Route::get('/allusers', '\App\Http\Controllers\AdminController@alluser')->name('allusers');

// for admin side
Route::resource('/products',\App\Http\Controllers\ProductController::class);
Route::resource('/newproducts',\App\Http\Controllers\NewproductController::class);
// cart part
Route::get('/cart', '\App\Http\Controllers\ProductController@viewCart');
Route::post('add-to-cart', '\App\Http\Controllers\ProductController@addToCart');
Route::get('/remove-item/{rowId}', '\App\Http\Controllers\ProductController@removeItem');
Route::get('/direct_cart', '\App\Http\Controllers\ProductController@direct');



//Route::resource('/products_new',\App\Http\Controllers\ProductnewController::class);
//Route::get('/after_login_details_cart', '\App\Http\Controllers\ProductController@show_after');

Route::post('add-to-cart_new', '\App\Http\Controllers\NewproductController@addToCart');
Route::get('/remove-item_new/{rowId}', '\App\Http\Controllers\NewproductController@removeItem');
Route::get('/new_cart', '\App\Http\Controllers\NewproductController@viewCartnew');
// Route::get('/productssssss', function () {
//     return view('products');
//  });


Route::get('/forgot-password', function () {
    return view('forgot_password');
})->middleware('guest')->name('password.request');




Route::get('/delete-products','\App\Http\Controllers\AdminController@sel');
Route::get('delete/{id}','\App\Http\Controllers\AdminController@des');


















use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

Route::post('/forgot-password', function (Request $request) {
    $request->validate(['email' => 'required|email']);

    $status = Password::sendResetLink(
        $request->only('email')
    );

    return $status === Password::RESET_LINK_SENT
                ? back()->with(['status' => __($status)])
                : back()->withErrors(['email' => __($status)]);
})->middleware('guest')->name('password.email');



Route::get('/reset-password/{token}', function ($token) {
    return view('reset-password', ['token' => $token]);
})->middleware('guest')->name('password.reset');


Route::post('/reset-password', function (Request $request) {
    $request->validate([
        'token' => 'required',
        'email' => 'required|email',
        'password' => 'required|min:8|confirmed',
    ]);

    $status = Password::reset(
        $request->only('email', 'password', 'password_confirmation', 'token'),
        function ($user, $password) {
            $user->forceFill([
                'password' => $password
            ])->setRememberToken(Str::random(60));

            $user->save();

            event(new PasswordReset($user));
        }
    );

    return $status === Password::PASSWORD_RESET
                ? redirect()->route('login1')->with('status', __($status))
                : back()->withErrors(['email' => [__($status)]]);
})->middleware('guest')->name('password.update');



// SSLCOMMERZ Start
Route::get('/example1', [\App\Http\Controllers\SslCommerzPaymentController::class, 'exampleEasyCheckout']);
Route::get('/example2', [\App\Http\Controllers\SslCommerzPaymentController::class, 'exampleHostedCheckout']);

Route::post('/pay', [\App\Http\Controllers\SslCommerzPaymentController::class, 'index']);
Route::post('/pay-via-ajax', [\App\Http\Controllers\SslCommerzPaymentController::class, 'payViaAjax']);

Route::post('/success', [\App\Http\Controllers\SslCommerzPaymentController::class, 'success']);
Route::post('/fail', [\App\Http\Controllers\SslCommerzPaymentController::class, 'fail']);
Route::post('/cancel', [\App\Http\Controllers\SslCommerzPaymentController::class, 'cancel']);

Route::post('/ipn', [\App\Http\Controllers\SslCommerzPaymentController::class, 'ipn']);
//SSLCOMMERZ END


// Route::get('login', 'Auth\LoginController@showLoginForm')->name('login');
// Route::post('login', 'Auth\LoginController@login')->name('saveLogin');
// Route::get('logout', 'Auth\LoginController@logout')->name('logout');

// // Registration Routes...
// Route::get('register', 'Auth\RegisterController@showRegistrationForm')->name('register');
// Route::post('register', 'Auth\RegisterController@register')->name('saveRegister');

// Password Reset Routes...
//Route::get('password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.request');
 //Route::post('password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
// Route::get('password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset');
// Route::post('password/reset', 'Auth\ResetPasswordController@reset')->name('password.update');

// // Confirm Password (added in v6.2)
// Route::get('password/confirm', 'Auth\ConfirmPasswordController@showConfirmForm')->name('password.confirm');
// Route::post('password/confirm', 'Auth\ConfirmPasswordController@confirm');

// // Email Verification Routes...
// Route::get('email/verify', 'Auth\VerificationController@show')->name('verification.notice');
// Route::get('email/verify/{id}/{hash}', 'Auth\VerificationController@verify')->name('verification.verify'); // v6.x
// /* Route::get('email/verify/{id}', 'Auth\VerificationController@verify')->name('verification.verify'); // v5.x */
// Route::get('email/resend', 'Auth\VerificationController@resend')->name('verification.resend');
